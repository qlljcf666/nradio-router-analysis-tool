module("luci.controller.nradio.at", package.seeall)

function index()
entry({"nradio","system","at"}, template("admin_system/at"), _("AT命令终端"), 99)
end