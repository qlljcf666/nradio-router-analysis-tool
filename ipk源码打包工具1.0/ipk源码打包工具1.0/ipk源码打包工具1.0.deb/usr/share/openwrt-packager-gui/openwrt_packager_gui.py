#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OpenWrt 插件打包工具 (IPK / APK)
=================================
将 luci-app-xxx 插件源码目录打包为:
  - IPK  (opkg 格式, OpenWrt <= 23.05)
  - APK  (apk v2 三段流格式, OpenWrt master/24.10+)

源码目录约定(与 OpenWrt luci.mk 一致):
  Makefile            必选, 解析 PKG_NAME/PKG_VERSION/PKG_RELEASE/LUCI_DEPENDS/conffiles
  root/    (或 files/) -> 打包到 /
  luasrc/             -> 打包到 /usr/lib/lua/luci/
  htdocs/             -> 打包到 /www/

特性:
  - 纯 Python 标准库, tkinter 单文件, 零第三方依赖, Windows/Linux 均可运行
  - USTAR 格式 tar(无 PAX 扩展头), gzip mtime=0 可复现构建
  - 自动识别 etc/init.d 服务与 etc/uci-defaults, 生成 postinst/prerm
  - 命令行模式: python openwrt_packager_gui.py --cli --src <dir> [--out <dir>] [--ipk] [--apk]
"""
APP_VERSION = '1.0'

import os
import io
import re
import sys
import gzip
import time
import threading

# =====================================================================
#  Makefile 解析
# =====================================================================

def _read_multiline_var(lines, name):
    """读取 Makefile 变量, 支持反斜杠续行"""
    pat = re.compile(r'^%s\s*:?=\s*(.*)$' % re.escape(name))
    out, capture = [], False
    for ln in lines:
        if not capture:
            m = pat.match(ln)
            if m:
                capture = True
                v = m.group(1).rstrip()
                if v.endswith('\\'):
                    out.append(v[:-1])
                else:
                    out.append(v)
                    break
        else:
            v = ln.strip()
            if v.endswith('\\'):
                out.append(v[:-1])
            else:
                out.append(v)
                break
    return ' '.join(out)


def parse_makefile(path):
    """解析 OpenWrt 包 Makefile, 返回 dict"""
    with open(path, encoding='utf-8', errors='ignore') as f:
        text = f.read()
    lines = text.splitlines()
    info = {}
    for key, name in (('name', 'PKG_NAME'), ('version', 'PKG_VERSION'),
                      ('release', 'PKG_RELEASE'), ('license', 'PKG_LICENSE'),
                      ('title', 'LUCI_TITLE'), ('maintainer', 'PKG_MAINTAINER')):
        v = _read_multiline_var(lines, name)
        if v:
            info[key] = v.strip()
    info.setdefault('release', '1')
    info.setdefault('license', 'GPLv3')
    info.setdefault('title', info.get('name', ''))
    info.setdefault('arch', 'all')

    # 依赖: 优先 LUCI_DEPENDS, 回退 DEPENDS
    dep_text = _read_multiline_var(lines, 'LUCI_DEPENDS') or _read_multiline_var(lines, 'DEPENDS')
    deps = []
    for tok in re.split(r'[\s\\]+', dep_text):
        tok = tok.strip()
        if not tok or tok.startswith('$') or tok.startswith('@'):
            continue
        if tok.startswith('+'):
            tok = tok[1:]
        if tok and tok not in deps:
            deps.append(tok)
    info['depends'] = deps

    # conffiles define 块
    info['conffiles'] = []
    m = re.search(r'define\s+Package/[\w.-]+/conffiles\s*\n(.*?)\nendef', text, re.S)
    if m:
        info['conffiles'] = [l.strip() for l in m.group(1).splitlines() if l.strip()]
    return info


# =====================================================================
#  文件收集 (luci.mk 路径映射)
# =====================================================================

def collect_files(src):
    """返回 [(arcname, 源绝对路径, mode)]，arcname 以 ./ 开头"""
    files = []

    def add_tree(sub, prefix):
        base = os.path.join(src, sub)
        if not os.path.isdir(base):
            return
        for root, _dirs, fns in os.walk(base):
            rel = os.path.relpath(root, base)
            for fn in sorted(fns):
                sp = os.path.join(root, fn)
                rp = fn if rel == '.' else os.path.join(rel, fn).replace('\\', '/')
                arc = './%s%s' % (prefix, rp)
                is_exec = fn.endswith('.sh') or rp.startswith('etc/init.d/')
                files.append((arc, sp, 0o755 if is_exec else 0o644))

    add_tree('root', '')
    if not os.path.isdir(os.path.join(src, 'root')):
        add_tree('files', '')          # 标准 OpenWrt package 惯例
    add_tree('luasrc', 'usr/lib/lua/luci/')
    add_tree('htdocs', 'www/')
    return files


# =====================================================================
#  安装脚本生成 (同时兼容 opkg IPKG_INSTROOT 与 apk)
# =====================================================================

def gen_scripts(files):
    svcs = sorted({a.split('/')[-1] for a, _, _ in files if a.startswith('./etc/init.d/')})
    ucid = sorted({a.split('/')[-1] for a, _, _ in files if a.startswith('./etc/uci-defaults/')})

    post = ['#!/bin/sh', 'if [ -z "${IPKG_INSTROOT}${APK_INSTROOT}" ]; then']
    for u in ucid:
        post.append('\t[ -f /etc/uci-defaults/%s ] && . /etc/uci-defaults/%s && rm -f /etc/uci-defaults/%s' % (u, u, u))
    post.append('\trm -f /tmp/luci-indexcache /tmp/luci-modulecache/*')
    for s in svcs:
        post.append('\t/etc/init.d/%s enable 2>/dev/null' % s)
    post.append('\texit 0')
    post.append('fi')

    pre = ['#!/bin/sh', 'if [ -z "${IPKG_INSTROOT}${APK_INSTROOT}" ]; then']
    for s in svcs:
        pre.append('\t/etc/init.d/%s stop 2>/dev/null' % s)
        pre.append('\t/etc/init.d/%s disable 2>/dev/null' % s)
    pre.append('\trm -f /tmp/luci-indexcache /tmp/luci-modulecache/*')
    pre.append('\texit 0')
    pre.append('fi')
    return ('\n'.join(post) + '\n').encode(), ('\n'.join(pre) + '\n').encode()


# =====================================================================
#  tar/gzip 底层工具 (手写 USTAR, 无 PAX, mtime=0)
#
#  为什么不用 Python tarfile 写入:
#  tarfile 构造 tar 头时会把 mode 强制掩码到 0o7777 (丢弃 S_IFDIR/S_IFREG
#  文件类型位), 而 opkg 的 tar 解析器依据 mode & S_IFMT 判断目录/文件。
#  缺少 S_IFDIR 的目录条目会被 opkg 当普通文件 wfopen, 报
#  "Is a directory" / "No such file or directory" 并导致全部文件安装失败。
#  GNU tar 写入的是完整 st_mode (如目录 040755), 此处手写 tar 头保持一致。
# =====================================================================

_S_IFDIR = 0o040000
_S_IFREG = 0o100000


def _tar_split_name(name):
    """USTAR name(100)/prefix(155) 拆分, 返回 (prefix, name) 字节串"""
    raw = name.encode('utf-8')
    if len(raw) <= 100:
        return b'', raw
    parts = name.split('/')
    for i in range(len(parts) - 1, 0, -1):
        nm = '/'.join(parts[i:])
        pf = '/'.join(parts[:i])
        if len(nm.encode('utf-8')) <= 100 and len(pf.encode('utf-8')) <= 155:
            return pf.encode('utf-8'), nm.encode('utf-8')
    raise ValueError('tar 路径过长无法编码: %s' % name)


def _tar_header(name, mode, size, typeflag, mtime=0):
    """构造 512 字节 USTAR 头, mode 为完整 st_mode (含文件类型位)"""
    prefix, nm = _tar_split_name(name)
    h = bytearray(512)
    h[0:len(nm)] = nm
    h[100:108] = b'%07o\0' % (mode & 0o777777)      # mode (含类型位)
    h[108:116] = b'%07o\0' % 0                       # uid
    h[116:124] = b'%07o\0' % 0                       # gid
    h[124:136] = b'%011o\0' % size                   # size
    h[136:148] = b'%011o\0' % mtime                  # mtime
    h[148:156] = b'        '                         # chksum 占位
    h[156:157] = typeflag                            # typeflag
    h[257:263] = b'ustar\0'                          # magic
    h[263:265] = b'00'                               # version
    h[265:269] = b'root'                             # uname
    h[297:301] = b'root'                             # gname
    if prefix:
        h[345:345 + len(prefix)] = prefix            # prefix
    h[148:156] = b'%06o\0 ' % sum(h)                 # chksum
    return bytes(h)


class TarWriter:
    """手写 USTAR writer: 目录条目 mode 带 S_IFDIR, 文件带 S_IFREG"""

    def __init__(self):
        self.buf = io.BytesIO()
        self._dirs = set()

    def _write_entry(self, name, mode, size, typeflag, payload=b''):
        self.buf.write(_tar_header(name, mode, size, typeflag))
        if payload:
            self.buf.write(payload)
            pad = (-len(payload)) % 512
            if pad:
                self.buf.write(b'\0' * pad)

    def add_file(self, name, data, mode=0o644):
        self._write_entry(name, mode | _S_IFREG, len(data), b'0', data)

    def add_dir(self, name, mode=0o755):
        if name in self._dirs:
            return
        self._dirs.add(name)
        if not name.endswith('/'):
            name += '/'
        self._write_entry(name, mode | _S_IFDIR, 0, b'5')

    def add_parent_dirs(self, arcname):
        parts = [p for p in arcname.strip('/').split('/') if p not in ('', '.')][:-1]
        for i in range(1, len(parts) + 1):
            self.add_dir('./' + '/'.join(parts[:i]) + '/')

    def finish(self):
        self.buf.write(b'\0' * 1024)
        return self.buf.getvalue()


def _gz(data):
    return gzip.compress(data, compresslevel=9, mtime=0)


# =====================================================================
#  IPK 构建 (opkg)
# =====================================================================

def build_ipk(info, files, out_dir, log=print):
    name = info['name']
    ver = '%s-%s' % (info['version'], info['release'])
    out_path = os.path.join(out_dir, '%s_%s_%s.ipk' % (name, ver, info['arch']))
    post, pre = gen_scripts(files)
    size = sum(os.path.getsize(sp) for _, sp, _ in files)

    ctl_lines = [
        'Package: %s' % name,
        'Version: %s' % ver,
        'Depends: %s' % ', '.join(info['depends']),
        'License: %s' % info['license'],
        'Section: luci',
        'Architecture: %s' % info['arch'],
        'Installed-Size: %d' % size,
        'Maintainer: %s' % info.get('maintainer', 'unknown'),
        'Description: %s' % info['title'],
    ]
    conff = (''.join(c + '\n' for c in info['conffiles'])).encode()

    # control.tar.gz
    tw = TarWriter()
    tw.add_file('./control', ('\n'.join(ctl_lines) + '\n').encode())
    if conff:
        tw.add_file('./conffiles', conff)
    tw.add_file('./postinst', post, 0o755)
    tw.add_file('./prerm', pre, 0o755)
    ctl_gz = _gz(tw.finish())

    # data.tar.gz (含显式目录条目, opkg 依赖其创建父目录)
    tw = TarWriter()
    for arc, sp, mode in files:
        tw.add_parent_dirs(arc)
        with open(sp, 'rb') as f:
            tw.add_file(arc, f.read(), mode)
    data_gz = _gz(tw.finish())

    # 外层 tar.gz
    tw = TarWriter()
    tw.add_file('./control.tar.gz', ctl_gz)
    tw.add_file('./data.tar.gz', data_gz)
    with open(out_path, 'wb') as f:
        f.write(_gz(tw.finish()))
    log('[IPK] %s  (%d 字节, %d 个文件)' % (out_path, os.path.getsize(out_path), len(files)))
    return out_path


# =====================================================================
#  APK 构建 (apk v2 三段流: [签名段]+控制段+数据段, 本工具无签名)
# =====================================================================

def build_apk(info, files, out_dir, log=print):
    name = info['name']
    ver = '%s-r%s' % (info['version'], info['release'])
    out_path = os.path.join(out_dir, '%s-%s.apk' % (name, ver))
    post, pre = gen_scripts(files)
    size = sum(os.path.getsize(sp) for _, sp, _ in files)

    pkg_lines = [
        'pkgname = %s' % name,
        'pkgver = %s' % ver,
        'pkgdesc = %s' % info['title'],
        'url = ',
        'builddate = %d' % int(time.time()),
        'packager = openwrt-packager-gui',
        'size = %d' % size,
        'arch = %s' % info['arch'],
        'origin = %s' % name,
        'license = %s' % info['license'],
    ]
    for d in info['depends']:
        pkg_lines.append('depend = %s' % d)
    pkginfo = ('\n'.join(pkg_lines) + '\n').encode()

    # 控制段: .PKGINFO + 安装脚本
    tw = TarWriter()
    tw.add_file('.PKGINFO', pkginfo)
    tw.add_file('.post-install', post, 0o755)
    tw.add_file('.pre-deinstall', pre, 0o755)
    ctl_gz = _gz(tw.finish())

    # 数据段
    tw = TarWriter()
    for arc, sp, mode in files:
        tw.add_parent_dirs(arc)
        with open(sp, 'rb') as f:
            tw.add_file(arc, f.read(), mode)
    data_gz = _gz(tw.finish())

    with open(out_path, 'wb') as f:
        f.write(ctl_gz + data_gz)   # apk v2: gzip 流直接拼接
    log('[APK] %s  (%d 字节, %d 个文件)' % (out_path, os.path.getsize(out_path), len(files)))
    return out_path


# =====================================================================
#  GUI
# =====================================================================

def run_gui():
    import tkinter as tk
    from tkinter import ttk, filedialog, scrolledtext, messagebox

    class App(tk.Tk):
        def __init__(self):
            super().__init__()
            self.title('OpenWrt 插件打包工具 (IPK / APK)  v%s' % APP_VERSION)
            self.geometry('760x640')
            self.minsize(700, 560)
            self.info = None
            self._build_ui()

        def _build_ui(self):
            pad = dict(padx=6, pady=4)

            # --- 源码目录 ---
            fr = ttk.LabelFrame(self, text='源码目录 (含 Makefile 的 luci-app-xxx 项目根目录)')
            fr.pack(fill='x', **pad)
            self.var_src = tk.StringVar()
            ttk.Entry(fr, textvariable=self.var_src).pack(side='left', fill='x', expand=True, padx=4, pady=4)
            ttk.Button(fr, text='浏览...', command=self.on_browse_src).pack(side='left', padx=4)
            ttk.Button(fr, text='解析 Makefile', command=self.on_parse).pack(side='left', padx=4)

            # --- 输出目录 ---
            fr = ttk.LabelFrame(self, text='输出目录 (留空 = 源码目录的上一级)')
            fr.pack(fill='x', **pad)
            self.var_out = tk.StringVar()
            ttk.Entry(fr, textvariable=self.var_out).pack(side='left', fill='x', expand=True, padx=4, pady=4)
            ttk.Button(fr, text='浏览...', command=self.on_browse_out).pack(side='left', padx=4)

            # --- 包信息 ---
            fr = ttk.LabelFrame(self, text='包信息 (解析 Makefile 后可编辑)')
            fr.pack(fill='x', **pad)
            self.vars = {}
            fields = [('name', '包名'), ('version', '版本'), ('release', 'Release'),
                      ('arch', '架构'), ('title', '描述'), ('license', '许可证')]
            for i, (k, label) in enumerate(fields):
                ttk.Label(fr, text=label, width=8).grid(row=i // 3, column=(i % 3) * 2, sticky='e', padx=2, pady=2)
                v = tk.StringVar()
                self.vars[k] = v
                ttk.Entry(fr, textvariable=v, width=22).grid(row=i // 3, column=(i % 3) * 2 + 1, sticky='w', padx=2, pady=2)

            fr2 = ttk.LabelFrame(self, text='依赖 / 配置文件 (只读)')
            fr2.pack(fill='x', **pad)
            self.var_deps = tk.StringVar()
            self.var_conf = tk.StringVar()
            ttk.Label(fr2, text='Depends:').grid(row=0, column=0, sticky='e', padx=2)
            ttk.Entry(fr2, textvariable=self.var_deps, state='readonly').grid(row=0, column=1, sticky='we', padx=2, pady=2)
            ttk.Label(fr2, text='conffiles:').grid(row=1, column=0, sticky='e', padx=2)
            ttk.Entry(fr2, textvariable=self.var_conf, state='readonly').grid(row=1, column=1, sticky='we', padx=2, pady=2)
            fr2.columnconfigure(1, weight=1)

            # --- 选项与操作 ---
            fr = ttk.Frame(self)
            fr.pack(fill='x', **pad)
            self.var_ipk = tk.BooleanVar(value=True)
            self.var_apk = tk.BooleanVar(value=True)
            ttk.Checkbutton(fr, text='生成 IPK (opkg)', variable=self.var_ipk).pack(side='left', padx=6)
            ttk.Checkbutton(fr, text='生成 APK (apk v2)', variable=self.var_apk).pack(side='left', padx=6)
            ttk.Button(fr, text='开始打包', command=self.on_build).pack(side='right', padx=6)
            ttk.Button(fr, text='打开输出目录', command=self.on_open_out).pack(side='right', padx=6)

            # --- 日志 ---
            fr = ttk.LabelFrame(self, text='日志')
            fr.pack(fill='both', expand=True, **pad)
            self.log_text = scrolledtext.ScrolledText(fr, height=14, font=('Consolas', 9))
            self.log_text.pack(fill='both', expand=True, padx=4, pady=4)

        # ---------- 事件 ----------
        def log(self, msg):
            self.log_text.insert('end', msg + '\n')
            self.log_text.see('end')
            self.update_idletasks()

        def on_browse_src(self):
            d = filedialog.askdirectory(title='选择插件源码目录')
            if d:
                self.var_src.set(d)
                self.on_parse()

        def on_browse_out(self):
            d = filedialog.askdirectory(title='选择输出目录')
            if d:
                self.var_out.set(d)

        def on_open_out(self):
            out = self.var_out.get().strip() or os.path.dirname(os.path.abspath(self.var_src.get().strip()))
            if os.path.isdir(out):
                if sys.platform == 'win32':
                    os.startfile(out)
                elif sys.platform == 'darwin':
                    os.system('open "%s"' % out)
                else:
                    os.system('xdg-open "%s" &' % out)
            else:
                messagebox.showwarning('提示', '输出目录不存在')

        def on_parse(self):
            src = self.var_src.get().strip()
            mk = os.path.join(src, 'Makefile')
            if not os.path.isfile(mk):
                messagebox.showerror('错误', '未找到 Makefile:\n%s' % mk)
                return
            try:
                info = parse_makefile(mk)
            except Exception as e:
                messagebox.showerror('解析失败', str(e))
                return
            if 'name' not in info:
                messagebox.showerror('解析失败', 'Makefile 中未找到 PKG_NAME')
                return
            self.info = info
            for k in ('name', 'version', 'release', 'arch', 'title', 'license'):
                self.vars[k].set(info.get(k, ''))
            self.var_deps.set(', '.join(info['depends']) or '(无)')
            self.var_conf.set(', '.join(info['conffiles']) or '(无)')
            files = collect_files(src)
            self.log('[解析] 包名=%s 版本=%s-%s 依赖=%d 个, 待打包文件=%d 个'
                     % (info['name'], info['version'], info['release'], len(info['depends']), len(files)))

        def on_build(self):
            src = self.var_src.get().strip()
            if not self.info:
                messagebox.showwarning('提示', '请先解析 Makefile')
                return
            if not (self.var_ipk.get() or self.var_apk.get()):
                messagebox.showwarning('提示', '请至少勾选一种输出格式')
                return
            # 应用编辑后的字段
            for k in ('name', 'version', 'release', 'arch', 'title', 'license'):
                self.info[k] = self.vars[k].get().strip() or self.info.get(k, '')
            out = self.var_out.get().strip() or os.path.dirname(os.path.abspath(src))
            os.makedirs(out, exist_ok=True)
            info = dict(self.info)
            do_ipk, do_apk = self.var_ipk.get(), self.var_apk.get()

            def work():
                try:
                    files = collect_files(src)
                    if not files:
                        self.log('[错误] 未收集到任何文件 (需要 root/ 或 luasrc/ 或 htdocs/ 目录)')
                        return
                    self.log('[开始] %s -> %s' % (src, out))
                    if do_ipk:
                        build_ipk(info, files, out, log=self.log)
                    if do_apk:
                        build_apk(info, files, out, log=self.log)
                    self.log('[完成] 打包结束')
                except Exception as e:
                    import traceback
                    self.log('[异常] %s' % e)
                    self.log(traceback.format_exc())

            threading.Thread(target=work, daemon=True).start()

    App().mainloop()


# =====================================================================
#  CLI 模式
# =====================================================================

def run_cli(argv):
    import argparse
    ap = argparse.ArgumentParser(description='OpenWrt 插件打包工具 (IPK/APK) v%s' % APP_VERSION)
    ap.add_argument('--version', action='version', version='%%(prog)s v%s' % APP_VERSION)
    ap.add_argument('--cli', action='store_true')
    ap.add_argument('--src', required=True, help='插件源码目录')
    ap.add_argument('--out', default=None, help='输出目录 (默认: 源码目录上一级)')
    ap.add_argument('--ipk', action='store_true', help='生成 IPK')
    ap.add_argument('--apk', action='store_true', help='生成 APK')
    args = ap.parse_args(argv)

    src = os.path.abspath(args.src)
    info = parse_makefile(os.path.join(src, 'Makefile'))
    files = collect_files(src)
    out = os.path.abspath(args.out) if args.out else os.path.dirname(src)
    os.makedirs(out, exist_ok=True)
    print('包名: %s 版本: %s-%s 架构: %s 文件: %d 个' %
          (info['name'], info['version'], info['release'], info['arch'], len(files)))
    if not args.ipk and not args.apk:
        args.ipk = args.apk = True
    if args.ipk:
        build_ipk(info, files, out)
    if args.apk:
        build_apk(info, files, out)


if __name__ == '__main__':
    if '--cli' in sys.argv:
        run_cli(sys.argv[1:])
    else:
        run_gui()
